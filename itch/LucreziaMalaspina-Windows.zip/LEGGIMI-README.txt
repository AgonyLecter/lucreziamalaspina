LUCREZIA MALASPINA — Una fiaba gotica in cinque capitoli
Sviluppato da AgonyApp

ITALIANO
--------
1. Avvia LucreziaMalaspina.exe: il gioco si apre a schermo intero.
2. Requisiti: Windows 10 o 11 (usa Microsoft Edge WebView2, già incluso in Windows).
   Se manca, scaricalo da: https://go.microsoft.com/fwlink/p/?LinkId=2124703
3. Al primo avvio Windows potrebbe mostrare "Windows ha protetto il PC":
   clicca "Ulteriori informazioni" e poi "Esegui comunque".
4. Per uscire: menu del titolo → "Esci dal gioco", oppure Alt+F4.
5. La lingua (italiano / inglese) si cambia dal menu del titolo o di pausa.
6. I salvataggi sono automatici, in: %APPDATA%\AgonyApp\LucreziaMalaspina
Si consiglia di giocare con le cuffie.

ENGLISH
-------
1. Run LucreziaMalaspina.exe: the game opens in full screen.
2. Requirements: Windows 10 or 11 (it uses Microsoft Edge WebView2, already included in Windows).
   If it is missing, download it from: https://go.microsoft.com/fwlink/p/?LinkId=2124703
3. On first launch Windows may show "Windows protected your PC":
   click "More info" and then "Run anyway".
4. To quit: title menu → "Quit game", or Alt+F4.
5. Switch language (Italian / English) from the title or pause menu.
6. Progress is saved automatically in: %APPDATA%\AgonyApp\LucreziaMalaspina
Headphones recommended.
